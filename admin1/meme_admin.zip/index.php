<?php include('header.php');?>
			<!-- end: header -->

			<div class="inner-wrapper">
				<!-- start: sidebar -->
				<?php include ('sidebar.php'); ?>
				<!-- end: sidebar -->
			</div>
<?php include('footer.php'); ?>